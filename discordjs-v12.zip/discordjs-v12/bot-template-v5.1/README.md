## About the project
The project was created in order not to suffer and immediately take a ready-made, but already convenient bot template.
## Description
__Bug fixes__, and addition of __functions__
## Bot template update `v5.1`
# Bugs
* Library update `RandomColorEmbed`
* Fixed a bug with the fact that it does not find the file `savebotconfing.txt`
* Correction of the code, instead of the text for reading commands, an array is set the `fs.readdir(...);`
* Fixed version of bot template in output console
# update
* Changed example command
* Added to `LauncherSystem` settings a file the `setting.json`, now you can change the name of `botconfig.json` without problems
* Added functions from me to `lib/functions.js`
