module.exports.run = (bot,message,args) => {
    message.channel.send("Привет");
};
module.exports.help = {
    name: "ping"
};
