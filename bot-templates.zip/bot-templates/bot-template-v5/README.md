# About the project
The project was created in order not to suffer and immediately take a ready-made, but already convenient bot template.
# Bot template update `v5.0`
* Added styling at startup

<p><img src="https://media.discordapp.net/attachments/757169876451196969/855825949606281246/Screenshot_2021-06-19-18-05-20-62.png" width"250" height="250" alt="Screenshot" /></p>

* Added saving botconfig.json file to savebotconfig.txt file

* You can also in botconfig.json where `user` write your discord nickname in order to show that this bot belongs to you, and not to someone
